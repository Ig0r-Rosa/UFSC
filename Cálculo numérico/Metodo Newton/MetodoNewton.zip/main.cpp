#include <iostream>
#include "metNew.hpp"  

int main()
{
    // Calcular(valor de A ; valor de B; erro ideal ; maximo de interações ; precisao do intervalo inicial)
    float resultado = metNewton::Calcular(-5, 5, 0.01, 100, 10);
    std::cout << "Resultado:" << resultado << std::endl;

    return 0;
}