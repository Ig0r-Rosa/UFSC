/**
 * Implemente aqui as funções dos sistema de arquivos que simula EXT3
 */


// includes
#include "fs.h" 
#include <iostream>
#include <cmath>
#include <fstream>

void initFs(std::string fsFileName, int blockSize, int numBlocks, int numInodes)
{
    std::fstream file{fsFileName, std::ios::out | std::ios::trunc};
    if(!file.is_open()){
        std::cout << "erro ao abrir!" << std::endl;
        return;
    }

    const char zero{0x00};
    // Mapa de bits - tamanho em bytes
    int tamMapaDeBits = std::ceil(numBlocks / 8.0);
    char mapaBits[tamMapaDeBits]{};
    // Define o primeiro bit do mapa de bits
    mapaBits[0] = 0x01;

    INODE slash{};
    slash.IS_DIR = 0x01;
    slash.IS_USED = 0x01;
    slash.NAME[0] = '/';

    //int tamanho = (numInodes -1) * sizeof(INODE) + 1 +blockSize * numBlocks;
    int tamSisArq = 3 + tamMapaDeBits + (sizeof(INODE) * numInodes) + (blockSize * numBlocks);

    file.write((const char*)&blockSize, 1);
    file.write((const char*)&numBlocks, 1);
    file.write((const char*)&numInodes, 1);
    file.write((const char*) mapaBits, tamMapaDeBits);
    file.write((const char*)&slash, sizeof(INODE));
    file.write((const char*)&blockSize, 1);
    for(int i = 0; i < tamSisArq; i++){
        file.write(&zero,1);
    }
    
    file.close();
}

void addFile(std::string fsFileName, std::string filePath, std::string fileContent)
{

}

void addDir(std::string fsFileName, std::string dirPath)
{

}

void remove(std::string fsFileName, std::string path)
{

}

void move(std::string fsFileName, std::string oldPath, std::string newPath)
{
    
}